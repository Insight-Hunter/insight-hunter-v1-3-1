# Insight Hunter — Starter v1.3.1 (Dynamic KPIs)

**Updates:**
- Forecast page fetches `/api/demo/forecast` and renders Chart.js dynamically.
- Reports page fetches `/api/demo/summary` and injects KPIs into a **Download PDF** (jsPDF).

## Quick Start
```bash
./install.sh
npm run dev
```
